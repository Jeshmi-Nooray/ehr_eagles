package com.infinite.ehrSystem.labResults.service;

import com.infinite.ehrSystem.exception.LabOrderNotFoundException;
import com.infinite.ehrSystem.labResults.dto.LabOrderDTO;
import com.infinite.ehrSystem.labResults.entity.LabOrder;
import com.infinite.ehrSystem.labResults.entity.LabOrderStatus;
import com.infinite.ehrSystem.labResults.repository.LabOrderRepository;
import com.infinite.ehrSystem.labResults.mapper.LabOrderMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class LabOrderServiceImpl implements LabOrderService {

    private static final Logger logger = LogManager.getLogger(LabOrderServiceImpl.class);

    private final LabOrderRepository labOrderRepository;
    private final LabOrderMapper labOrderMapper;

    public LabOrderServiceImpl(
            LabOrderRepository labOrderRepository,
            LabOrderMapper labOrderMapper) {

        this.labOrderRepository = labOrderRepository;
        this.labOrderMapper = labOrderMapper;
    }

    @Override
    public LabOrderDTO createLabOrder(LabOrderDTO dto) {
        logger.info("Creating lab order");

        LabOrder labOrder = labOrderMapper.toEntity(dto);
        labOrder.setId(null);
        if (labOrder.getStatus() == null) {
            labOrder.setStatus(LabOrderStatus.ORDERED);
        }

        LabOrder savedOrder =
                labOrderRepository.save(labOrder);

        return labOrderMapper.toDTO(savedOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public LabOrderDTO getLabOrderById(UUID id) {
        logger.debug("Loading lab order");

        LabOrder labOrder =
                labOrderRepository.findById(id).orElseThrow(() ->
                                new LabOrderNotFoundException("Lab order not found with id: " + id));
        return labOrderMapper.toDTO(labOrder);
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabOrderDTO> getLabOrdersByVisitId(UUID visitId) {
        return labOrderRepository
                .findByVisitId(visitId)
                .stream()
                .map(labOrderMapper::toDTO)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<LabOrderDTO> getLabOrdersByVisitIdAndStatus(UUID visitId, LabOrderStatus status) {
        return labOrderRepository
                .findByVisitIdAndStatus(visitId, status)
                .stream()
                .map(labOrderMapper::toDTO)
                .toList();
    }

    @Override
    public LabOrderDTO updateLabOrder(UUID id, LabOrderDTO dto) {
        logger.info("Updating lab order");
        LabOrder labOrder = labOrderRepository.findById(id).orElseThrow(() ->
                        new LabOrderNotFoundException("Lab order not found with id: " + id));
        LabOrder mappedLabOrder = labOrderMapper.toEntity(dto);
        labOrder.setVisitId(mappedLabOrder.getVisitId());
        labOrder.setTestName(mappedLabOrder.getTestName());

        if (mappedLabOrder.getStatus() != null)
        {
            labOrder.setStatus(mappedLabOrder.getStatus());
        }

        LabOrder updatedOrder =
                labOrderRepository.save(labOrder);

        return labOrderMapper.toDTO(updatedOrder);
    }

    @Override
    public void deleteLabOrder(UUID id) {
        logger.info("Deleting lab order");

        if (!labOrderRepository.existsById(id)) {
            throw new LabOrderNotFoundException(
                    "Lab order not found with id: " + id
            );
        }

        labOrderRepository.deleteById(id);
    }
}
